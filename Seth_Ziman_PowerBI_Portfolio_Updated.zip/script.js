document.addEventListener("DOMContentLoaded", function () {
  const year = document.getElementById("year");
  const menuToggle = document.getElementById("menuToggle");
  const navMenu = document.getElementById("navMenu");

  // Automatically update the copyright year.
  if (year) {
    year.textContent = new Date().getFullYear();
  }

  // Mobile navigation.
  if (menuToggle && navMenu) {
    menuToggle.addEventListener("click", function () {
      const isOpen = navMenu.classList.toggle("open");

      menuToggle.setAttribute(
        "aria-expanded",
        isOpen ? "true" : "false"
      );

      menuToggle.setAttribute(
        "aria-label",
        isOpen ? "Close navigation menu" : "Open navigation menu"
      );

      menuToggle.textContent = isOpen ? "Close" : "Menu";
    });

    navMenu.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        navMenu.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Open navigation menu");
        menuToggle.textContent = "Menu";
      });
    });
  }

  // Friendly message for projects that do not have a real report yet.
  document.querySelectorAll('[data-placeholder="true"]').forEach(function (link) {
    link.addEventListener("click", function (event) {
      event.preventDefault();

      alert(
        "This project does not have a live dashboard link yet. Replace the placeholder link in index.html with your Power BI report URL."
      );
    });
  });
});
