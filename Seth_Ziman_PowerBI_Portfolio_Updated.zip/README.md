# Seth Ziman — Power BI Portfolio

A static Power BI portfolio built with plain HTML, CSS, and JavaScript. It is designed to work on GitHub Pages without a build step or framework.

## Files

```text
index.html
styles.css
script.js
README.md
resume.pdf
images/
└── customer-dashboard.png
```

## 1. Change your name, bio, projects, and links

Open `index.html` in a text editor.

### Name

Search for:

```text
Seth Ziman
```

Replace it wherever necessary.

### Bio

The About section contains the current placeholder bio. Replace those paragraphs with your own background, skills, and career goals.

### Project descriptions

Each project is an `<article class="project-card">`.

Change the project title, description, category, and tags as you add real dashboards.

### LinkedIn

Near the bottom of `index.html`, find:

```html
href="https://www.linkedin.com/in/your-linkedin-profile/"
```

Replace it with your real LinkedIn profile URL.

### Email

The current email is:

```text
sziman19@gmail.com
```

Replace it if needed.

## 2. Add Power BI screenshots or reports

### Screenshot

The first real dashboard is already included:

```text
images/customer-dashboard.png
```

To replace it later, use the same filename or change the `src` in `index.html`.

The relevant HTML is:

```html
<img
  src="images/customer-dashboard.png"
  alt="Guest Experience and Wait-Time Analysis Power BI dashboard"
>
```

### Power BI report link

For the Customer Experience project, find:

```html
href="YOUR-POWER-BI-LINK-HERE"
```

Replace it with your published Power BI report URL.

For example:

```html
<a
  class="project-link"
  href="https://app.powerbi.com/view?r=YOUR-REPORT-ID"
  target="_blank"
  rel="noopener"
>
  View dashboard <span>↗</span>
</a>
```

Do not leave `data-placeholder="true"` on a real report link.

### Embedded Power BI report

If you decide to embed a published-to-web report instead of using a screenshot, you can replace the image with an iframe such as:

```html
<div class="powerbi-embed">
  <iframe
    title="Power BI report"
    width="100%"
    height="100%"
    src="YOUR-POWER-BI-EMBED-URL"
    frameborder="0"
    allowfullscreen="true">
  </iframe>
</div>
```

Only use a Power BI link that is appropriate for public sharing. Do not publish confidential or private business data publicly.

## 3. Add your resume

Put your resume PDF in the same folder as `index.html` and name it:

```text
resume.pdf
```

The Resume buttons already point to that filename.

## 4. Deploy with GitHub Pages

1. Create a new GitHub repository.
2. Upload:
   - `index.html`
   - `styles.css`
   - `script.js`
   - `README.md`
   - `resume.pdf`
   - the entire `images` folder
3. Commit and push the files to the `main` branch.
4. Open the repository on GitHub.
5. Go to **Settings**.
6. Select **Pages**.
7. Under **Build and deployment**, choose **Deploy from a branch**.
8. Select the `main` branch.
9. Select `/ (root)` as the folder.
10. Click **Save**.
11. GitHub will provide the website URL after deployment finishes.

## Important

Keep the file names and folder structure consistent. In particular:

```text
index.html
styles.css
script.js
resume.pdf
images/customer-dashboard.png
```

GitHub Pages is case-sensitive, so `Customer-Dashboard.png` is not the same as `customer-dashboard.png`.
